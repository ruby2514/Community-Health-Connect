</div> <!-- /.container -->
</main>

<footer class="site-footer py-3 mt-auto">
  <div class="container main-container d-flex justify-content-between align-items-center">
    <small>&copy; <?= date('Y') ?> Community Health Connect</small>
    <small class="d-none d-sm-inline">Built for CSIT 337</small>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>